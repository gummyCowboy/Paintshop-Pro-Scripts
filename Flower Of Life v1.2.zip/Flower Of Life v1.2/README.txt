About The Flower Of Life Script

Are There Any Prerequisites?
I made the script using PSP X9. The script should run X5+.
The script creates an image any without other requirements.

Where to put the script?
The script runs from restricted script folders, so there are no limitations.

What Are The Steps?
The script has several steps where it will ask for your input.

The steps:

1) Set the radius of the Flower of Life symbol. The radius is half the width of the symbol's size.

2) Enter the flower type. Enter 1, 2, or 3:
    One is an image made from lines.
    Two is an image made from the intersection of the circles. These are the pedals.
    Three is an image made from the circles.

3) If you entered one, then you can set the width of the image lines in the next dialog.

4) Enter the width of the surrounding circle. This circle is drawn around the Flower of Life symbol. It forms sort of a frame. If you enter zero for the width value, then the circle is not drawn. If you color the symbol, the circle is colored with the average color.

5) Color the Flower of Life symbol. You can choose to color the symbol, or if you don't, the script will stop at this point. The result is that you have a black and white image that is suitable for mask operations.

6) Choose a colors theme. Option one is the preset theme, and option two is to create random colors. Random colors will create a random preset. If you want to create your own presets, there are a few notes in the script header on how to add presets.

7) Increase the gradient effect. If you want darker edges and a little more contrast to the symbol, choose yes.

8) Add a drop shadow. The script will let you add a drop shadow.

----------------------------
Recycle The Selection
You can load the selection from the alpha channel. It is called 'flower'.

PSP slowing down?
Shut it down and restart it.
----------------------------
Updates:
	v1.1 (April 9, 2020): Made the gradient layer properties interactive, and changed the default blend mode property from multiply to difference.
    v1.2 (April 9, 2020): Made both of the gradient layer properties interactive.
		


I hope you enjoy the script. It was a fun project.

Charles Bartley


